import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/landing_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/main_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // TODO: Initialize Supabase
  // await Supabase.initialize(
  //   url: 'YOUR_SUPABASE_URL',
  //   anonKey: 'YOUR_SUPABASE_ANON_KEY',
  // );

  runApp(const RalllyApp());
}

class RalllyApp extends StatelessWidget {
  const RalllyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rallly',
      debugShowCheckedModeBanner: false,
      theme: RallyTheme.light,
      darkTheme: RallyTheme.dark,
      themeMode: ThemeMode.light,  // auto-switch: ThemeMode.system
      home: const _AppRouter(),
    );
  }
}

// ─── Simple auth router ───────────────────────────────────────────────────────
class _AppRouter extends StatefulWidget {
  const _AppRouter();

  @override
  State<_AppRouter> createState() => _AppRouterState();
}

class _AppRouterState extends State<_AppRouter> {
  _AppPage _page = _AppPage.landing;
  bool _isSignUp = true;
  String? _otpEmail;

  @override
  Widget build(BuildContext context) {
    return switch (_page) {
      _AppPage.landing => LandingScreen(
          onGetStarted: () => setState(() {
            _isSignUp = true;
            _page = _AppPage.authEmail;
          }),
          onSignIn: () => setState(() {
            _isSignUp = false;
            _page = _AppPage.authEmail;
          }),
        ),

      _AppPage.authEmail => AuthEmailScreen(
          isSignUp: _isSignUp,
          onOtpSent: (email) => setState(() {
            _otpEmail = email;
            _page = _AppPage.authOtp;
          }),
          onBack: () => setState(() => _page = _AppPage.landing),
        ),

      _AppPage.authOtp => AuthOtpScreen(
          email: _otpEmail ?? '',
          onVerified: () => setState(() => _page = _AppPage.home),
          onBack: () => setState(() => _page = _AppPage.authEmail),
        ),

      _AppPage.home => const MainShell(),
    };
  }
}

enum _AppPage { landing, authEmail, authOtp, home }
